package com.sai.stories.controller;

import com.sai.stories.model.Booking;
import com.sai.stories.model.MealPlan;
import com.sai.stories.repository.BookingRepository;
import com.sai.stories.repository.MealPlanRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
@CrossOrigin
public class BookingController {

    private final BookingRepository bookingRepo;
    private final MealPlanRepository mealRepo;

    // US-3 Add meal plan
    @PostMapping("/{id}/meal-plan")
    public Booking addMealPlan(@PathVariable Long id, @RequestParam Long mealPlanId) {
        Booking booking = bookingRepo.findById(id).orElseThrow();
        MealPlan mealPlan = mealRepo.findById(mealPlanId).orElseThrow();
        booking.setMealPlan(mealPlan);
        return bookingRepo.save(booking);
    }

    // US-4 Request room upgrade
    @PostMapping("/{id}/upgrade")
    public Booking requestRoomUpgrade(@PathVariable Long id) {
        Booking booking = bookingRepo.findById(id).orElseThrow();
        booking.setUpgradeRequested(true);
        return bookingRepo.save(booking);
    }
}
