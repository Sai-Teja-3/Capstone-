package com.sai.stories.controller;

import com.sai.stories.dto.CompareRequest;
import com.sai.stories.model.Hotel;
import com.sai.stories.repository.HotelRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hotels")
@RequiredArgsConstructor
@CrossOrigin
public class HotelController {

    private final HotelRepository hotelRepo;

    // US-1 Filter hotels by price
    @GetMapping("/filter")
    public List<Hotel> filterByPrice(@RequestParam double min, @RequestParam double max) {
        return hotelRepo.findByMinPriceGreaterThanEqualAndMaxPriceLessThanEqual(min, max);
    }

    // US-2 Compare multiple hotels
    @PostMapping("/compare")
    public List<Hotel> compareHotels(@RequestBody CompareRequest request) {
        return hotelRepo.findAllById(request.getHotelIds());
    }
}
