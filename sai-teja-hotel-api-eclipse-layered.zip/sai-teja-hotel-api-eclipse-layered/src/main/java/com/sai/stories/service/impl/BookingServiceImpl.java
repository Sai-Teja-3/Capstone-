package com.sai.stories.service.impl;

import com.sai.stories.model.Booking;
import com.sai.stories.model.MealPlan;
import com.sai.stories.repository.BookingRepository;
import com.sai.stories.repository.MealPlanRepository;
import com.sai.stories.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service @RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepo;
    private final MealPlanRepository mealRepo;

    @Override
    public Booking addMealPlan(Long bookingId, Long mealPlanId) {
        Booking booking = bookingRepo.findById(bookingId).orElseThrow();
        MealPlan mealPlan = mealRepo.findById(mealPlanId).orElseThrow();
        booking.setMealPlan(mealPlan);
        return bookingRepo.save(booking);
    }

    @Override
    public Booking requestUpgrade(Long bookingId) {
        Booking booking = bookingRepo.findById(bookingId).orElseThrow();
        booking.setUpgradeRequested(true);
        return bookingRepo.save(booking);
    }
}
