package com.sai.stories.service.impl;

import com.sai.stories.model.Hotel;
import com.sai.stories.repository.HotelRepository;
import com.sai.stories.service.HotelService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service @RequiredArgsConstructor
public class HotelServiceImpl implements HotelService {

    private final HotelRepository repo;

    @Override
    public List<Hotel> filterByPrice(double min, double max) {
        return repo.findByMinPriceGreaterThanEqualAndMaxPriceLessThanEqual(min, max);
    }

    @Override
    public List<Hotel> compareHotels(List<Long> ids) {
        return repo.findAllById(ids);
    }
}
