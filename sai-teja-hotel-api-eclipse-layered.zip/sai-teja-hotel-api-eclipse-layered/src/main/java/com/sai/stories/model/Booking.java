package com.sai.stories.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Table(name="booking")
public class Booking {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="user_id")
    private Long userId;

    @ManyToOne @JoinColumn(name="hotel_id") private Hotel hotel;
    @ManyToOne @JoinColumn(name="room_id") private Room room;
    @ManyToOne @JoinColumn(name="meal_plan_id") private MealPlan mealPlan;

    @Column(name="upgrade_requested")
    private boolean upgradeRequested;
}
