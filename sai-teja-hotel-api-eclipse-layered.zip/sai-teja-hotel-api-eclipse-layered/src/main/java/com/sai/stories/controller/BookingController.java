package com.sai.stories.controller;

import com.sai.stories.model.Booking;
import com.sai.stories.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
@CrossOrigin
public class BookingController {

    private final BookingService service;

    @PostMapping("/{id}/meal-plan")
    public Booking addMealPlan(@PathVariable Long id, @RequestParam Long mealPlanId) {
        return service.addMealPlan(id, mealPlanId);
    }

    @PostMapping("/{id}/upgrade")
    public Booking upgrade(@PathVariable Long id) {
        return service.requestUpgrade(id);
    }
}
