package com.sai.stories.dto;

import lombok.Data;
import java.util.List;

@Data
public class CompareRequest {
    private List<Long> hotelIds;
}
