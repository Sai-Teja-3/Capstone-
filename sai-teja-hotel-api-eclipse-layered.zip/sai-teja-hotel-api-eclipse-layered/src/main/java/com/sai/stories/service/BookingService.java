package com.sai.stories.service;

import com.sai.stories.model.Booking;

public interface BookingService {
    Booking addMealPlan(Long bookingId, Long mealPlanId);
    Booking requestUpgrade(Long bookingId);
}
