package com.sai.stories.controller;

import com.sai.stories.dto.CompareRequest;
import com.sai.stories.model.Hotel;
import com.sai.stories.service.HotelService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/hotels")
@RequiredArgsConstructor
@CrossOrigin
public class HotelController {

    private final HotelService service;

    @GetMapping("/filter")
    public List<Hotel> filterByPrice(@RequestParam double min, @RequestParam double max) {
        return service.filterByPrice(min, max);
    }

    @PostMapping("/compare")
    public List<Hotel> compare(@RequestBody CompareRequest req) {
        return service.compareHotels(req.getHotelIds());
    }
}
