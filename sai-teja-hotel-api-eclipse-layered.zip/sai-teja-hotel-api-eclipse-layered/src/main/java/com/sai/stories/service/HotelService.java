package com.sai.stories.service;

import com.sai.stories.model.Hotel;
import java.util.List;

public interface HotelService {
    List<Hotel> filterByPrice(double min, double max);
    List<Hotel> compareHotels(List<Long> ids);
}
