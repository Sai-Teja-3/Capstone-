import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent { 
  min = 2000;
  max = 5000;

  hotels:any[] = [];
  compareList:number[] = [];

  backend = 'http://localhost:8080';

  async filterHotels(){
    const url = `${this.backend}/api/hotels/filter?min=${this.min}&max=${this.max}`;
    const res = await fetch(url);
    this.hotels = await res.json();
  }

  toggleCompare(id:number){
    if(this.compareList.includes(id)){
      this.compareList = this.compareList.filter(x => x !== id);
    } else {
      this.compareList.push(id);
    }
  }

  async compareHotels(){
    const res = await fetch(`${this.backend}/api/hotels/compare`,{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({hotelIds:this.compareList})
    });
    this.hotels = await res.json();
  }
}
