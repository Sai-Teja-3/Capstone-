package com.sai.stories.repository;

import com.sai.stories.model.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface HotelRepository extends JpaRepository<Hotel, Long> {
    List<Hotel> findByMinPriceGreaterThanEqualAndMaxPriceLessThanEqual(double min, double max);
}
